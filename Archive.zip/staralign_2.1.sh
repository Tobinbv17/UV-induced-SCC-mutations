#!/bin/bash
#BSUB -J xunwei
#BSUB -o output/%J.out
#BSUB -e output/%J.err

#declare -A filenames
while IFS='' read -r line || [[ -n "$line" ]]
do
	#stringarray=($line)
	filename+="${line} "	
	#seq=${filename:0:3}
	#filenames[$seq]+="${filename} "
	#echo ${filenames[$seq]}
done < list


###############################################
UNMAPPED='/PHShome/yz843/xunwei20210424'
for seq in ${filename} 
do
	readFilesIn="${UNMAPPED}/${seq}"
	# echo ${tmpRG} can only put here, outside of the loop will only take the last value, which is only .2 files will be retained.	
    ./staralign_2.2.sh "${seq}" "${readFilesIn}" 
done


