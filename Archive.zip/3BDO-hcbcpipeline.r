## Gene-level differential expression analysis using DESeq2
library(tidyverse)
library(RColorBrewer)
library(DESeq2)
library(pheatmap)
library(DEGreport)
library(tibble)
#1. load data
data = readRDS('data/20210426_htseqcounts.rds')
meta = readRDS('meta/20210426_QC.rds') %>% mutate(group = gsub("_1",'',barcode)) %>%
  column_to_rownames('barcode') %>% separate(group, c('group','replicate'),sep = 'h') %>%
  separate(group,c('origin','treatment'),sep = '_')
  
class(meta)
class(data)
#To determine the appropriate statistical model, we need information about the distribution of counts
ggplot(data) +
  geom_histogram(aes(x = data$Der_3BDO12h1_1), stat = "bin", bins = 200) +
  xlab("Raw expression counts") +
  ylab("Number of genes")
#If we zoom in close to zero, we can see a large number of genes with counts of zero:
#common features of RNA-seq count data, including a low number of counts associated with a large proportion of genes, and a long right tail due to the lack of any upper limit for expression. Unlike microarray data, which has a dynamic range maximum limited due to when the probes max out, there is no limit of maximum expression for RNA-seq data. Due to the differences in these technologies, the statistical models used to fit the data are different between the two methods.

#2.Modeling count data
#Count data is often modeled using the binomial distribution, which can give you the probability of getting a number of heads upon tossing a coin a number of times. 
#When the number of cases is very large (i.e. people who buy lottery tickets), but the probability of an event is very small (probability of winning), the Poisson distribution is used to model these types of count data. The Poisson is similar to the binomial, but is based on continuous event
#The model that fits best, given this type of variability between replicates, is the Negative Binomial (NB) model. Essentially, the NB model is a good approximation for data where the mean < variance, as is the case with RNA-Seq count data.
#If it’s count data, it should fit the negative binomial, as discussed previously. However, it can be helpful to plot the mean versus the variance of your data. Remember for the Poisson model, mean = variance, but for NB, mean < variance.
mean_counts <- apply(data[, 1:3], 1, mean)
variance_counts <- apply(data[, 1:3], 1, var)
df <- data.frame(mean_counts, variance_counts)
ggplot(df) +
  geom_point(aes(x=mean_counts, y=variance_counts)) + 
  geom_line(aes(x=mean_counts, y=mean_counts, color="red")) +
  scale_y_log10() +
  scale_x_log10()
#Note that in the above figure, the variance across replicates tends to be greater than the mean (red line), especially for genes with large mean expression levels. This is a good indication that our data do not fit the Poisson distribution and we need to account for this increase in variance using the Negative Binomial model (i.e. Poisson will underestimate variability leading to an increase in false positive DE genes).

#3.Improving mean estimates (i.e. reducing variance) with biological replicates
#Note that an increase in the number of replicates tends to return more DE genes than increasing the sequencing depth. Therefore, generally more replicates are better than higher sequencing depth,
#Generally, the minimum sequencing depth recommended is 20-30 million reads per sample

#4. Differential expression analysis workflow

#4.1 Normalization
#Normalization is the process of scaling raw count values to account for the “uninteresting” factors. In this way the expression levels are more comparable between and/or within samples.
#The main factors often considered during normalization are:
#1)Sequencing depth,
#2)Gene length: Accounting for gene length is necessary for comparing expression between different genes within the same sample.
#3)RNA composition: A few highly differentially expressed genes between samples, differences in the number of genes expressed between samples, or presence of contamination can skew some types of normalization methods. Accounting for RNA composition is recommended for accurate comparison of expression between samples, and is particularly important when performing differential expression analyses 

#4.2 DESeq2-normalized counts: Median of ratios method
#Step 1: creates a pseudo-reference sample (row-wise geometric mean)
#Step 2: calculates ratio of each sample to the reference
#Step 3: calculate the normalization factor for each sample (size factor): The median value (column-wise for the above table) of all ratios for a given sample is taken as the normalization factor (size factor) for that sample
#Step 4: calculate the normalized count values using the normalization factor

#4.3 perform count normalization using DESeq2
#4.3.1. Match the metadata and counts data
### Check that sample names match in both files
all(colnames(data) %in% rownames(meta))
all(colnames(data) == rownames(meta))
#4.3.2 Create DESEq2 object
dds <- DESeqDataSetFromMatrix(countData = data, colData = meta, design = ~ origin+treatment)
#4.3.3 Generate the normalized counts
dds <- DESeq(dds)

#5. Unsupervised clustering analyses
#5.1 Sample-level QC:A useful initial step in an RNA-seq analysis is often to assess overall similarity between samples:
#PCA and Hierarchical Clustering Heatmap
#5.2 Gene-level QC The genes omitted fall into three categories:Genes with zero counts in all samples,Genes with an extreme count outlier,Genes with a low mean normalized counts
#5.3 perform quality assessment and exploratory analysis using DESeq2
#5.3.1 Transform normalized counts using the rlog transformation : To improve the distances/clustering for the PCA and heirarchical clustering visualization methods, we need to moderate the variance across the mean by applying the rlog transformation to the normalized counts.The rlog transformation of the normalized counts is only necessary for these visualization methods during this quality assessment. We will not be using these tranformed counts downstream.
### Transform counts for data visualization
#vsd <- vst(dds, blind=FALSE) faster then rlog
rld <- rlog(dds, blind=F)
#5.3.2Principal components analysis (PCA)
### Extract the rlog matrix from the object
rld_mat = assay(rld)
pca <- prcomp(t(rld_mat))
df <- cbind(meta,pca$x)
ggplot(df) + geom_point(aes(PC1,PC2,color=origin))
ggplot(df) + geom_point(aes(PC1,PC2,color=treatment))
ggplot(df) + geom_point(aes(PC1,PC2,color=group))
#5.3.3 Hierarchical Clustering
### Extract the rlog matrix from the object
rld_mat = assay(rld)
### Compute pairwise correlation values
rld_cor <- cor(rld_mat)
### Plot heatmap
pheatmap(rld_cor)
heat.colors <- brewer.pal(6, "Blues")
pheatmap(rld_cor, color = heat.colors, border_color=NA, fontsize = 10, 
         fontsize_row = 10, height=20)

#6.Differential expression analysis with DESeq2
#The final step in the differential expression analysis workflow is fitting the raw counts to the NB model and performing the statistical test for differentially expressed genes. In this step we essentially want to determine whether the mean expression levels of different sample groups are significantly different.
#Once you know the major sources of variation, you can remove them prior to analysis or control for them in the statistical model by including them in your design formula.
#6.1 Design formula
#The design formula should have all of the factors in your metadata that account for major sources of variation in your data. The last factor entered in the formula should be the condition of interest.
#If you want to examine the expression differences between treatments, and you know that major sources of variation include sex and age, then your design formula would be: design <- ~ sex + age + treatment
#6.2 Complex designs
#For example, if you wanted to explore the effect of sex on the treatment effect, you could specify for it in the design formula as follows:
#design <- ~ sex + age + treatment + sex:treatment
#The design ~ sex + age + treatment + treat_sex won’t work (because the model can’t be fit) because treatment and treat_sex are confounded (same goes for sex). Therefore, we drop the terms that went into treat_sex from the design formula.
meta$group = paste(meta$origin, meta$treatment, sep = '_')
#6.3 DE analysis. Now that we know how to specify the model to DESeq2, we can run the differential expression pipeline on the raw counts.
#6.3.1## Create DESeq object
dds <- DESeqDataSetFromMatrix(countData = data, colData = meta, design = ~ group)
## Run analysis
dds <- DESeq(dds)
#6.3.2 DESeq2 differential gene expression analysis workflow
#Step 1: Estimate size factors
sizeFactors(dds)
colSums(counts(dds))
colSums(counts(dds,normalized=T))
#Step 2: Estimate gene-wise dispersion
#DESeq2 uses a specific measure of dispersion (α) related to the mean (μ) and variance of the data: Var = μ + α*μ^2. For genes with moderate to high count values, the square root of dispersion will be equal to the coefficient of variation (Var / μ). So 0.01 dispersion means 10% variation around the mean expected across biological replicates.
#The DESeq2 dispersion estimates are inversely related to the mean and directly related to variance. Based on this relationship, the dispersion is higher for small mean counts and lower for large mean counts. The dispersion estimates for genes with the same mean will differ only based on their variance. Therefore, the dispersion estimates reflect the variance in gene expression for a given mean value.
#DESeq2 shares information across genes to generate more accurate estimates of variation based on the mean expression level of the gene using a method called ‘shrinkage’. DESeq2 assumes that genes with similar expression levels have similar dispersion.
#Step 3: Fit curve to gene-wise dispersion estimates
#This curve is displayed as a red line in the figure below, which plots the estimate for the expected dispersion value for genes of a given expression strength.
#Step 4: Shrink gene-wise dispersion estimates toward the values predicted by the curve
#Dispersion estimates that are slightly above the curve are also shrunk toward the curve for better dispersion estimation; however, genes with extremely high dispersion values are not. This is due to the likelihood that the gene does not follow the modeling assumptions and has higher variability than others for biological or technical reasons 
plotDispEsts(dds)

#7.Differential expression analysis with DESeq2: model fitting and hypothesis testing
#7.1 Generalized Linear Model fit for each gene
#Modeling is a mathematically formalized way to approximate how the data behaves given a set of parameters (i.e. size factor, dispersion). DESeq2 will use this formula as our model for each gene, and fit the normalized count data to it. After the model is fit, coefficients are estimated for each sample group along with their standard error using the formula
#The coefficents are the estimates for the log2 foldchanges for each sample group. However, these estimates do not account for the large dispersion we observe with low read counts. To avoid this, the log2 fold changes calculated by the model need to be adjusted.
#7.2 Shrunken log2 foldchanges (LFC)
#DESeq2 allows for the shrinkage of the LFC estimates toward zero when the information for a gene is low, which could include:Low counts,High dispersion values
#So even though two genes can have similar normalized count values, they can have differing degrees of LFC shrinkage. Notice the LFC estimates are shrunken toward the prior (black solid line).
#In the most recent versions of DESeq2, the shrinkage of LFC estimates is not performed by default,To generate the shrunken log2 fold change estimates, you have to run an additional step on your results object (that we will create below) with the function lfcShrink().

#8 Hypothesis testing using the Wald test
#The first step in hypothesis testing is to set up a null hypothesis for each gene. In our case is, the null hypothesis is that there is no differential expression across the two sample groups (LFC == 0). 
#With DESeq2, the Wald test is commonly used for hypothesis testing when comparing two groups. A Wald test statistic is computed along with a probability that a test statistic at least as extreme as the observed value were selected at random
#This probability is called the p-value of the test. If the p-value is small we reject the null hypothesis and state that there is evidence against the null
#8.1 Creating contrasts
#8.2 Building the results table
#8.3 perform the wald test
## Define contrasts, extract results table, and shrink the log2 fold changes
gtf = readRDS('data/Homo_sapiens.GRCh38.102.gtf.rds') %>% select(6:8)
contrast_3BDO_der_12 <- c("group", "Der_3BDO12", "Der_Ctrl12")
res_3BDO_der_12_unshrunken <- results(dds, contrast=contrast_3BDO_der_12)
res_3BDO_der_12 <- lfcShrink(dds, contrast=contrast_3BDO_der_12, res=res_3BDO_der_12_unshrunken)
plotMA(res_3BDO_der_12_unshrunken)
plotMA(res_3BDO_der_12)
df = res_3BDO_der_12_unshrunken%>% data.frame() %>% filter(!is.na(pvalue)) %>% 
  mutate(gene_id = paste(rownames(.)),
         sig = ifelse(df$log2FoldChange>=2 & df$pvalue <.01 | 
                        df$log2FoldChange <= -2 & df$pvalue <.01,'DEgene','nonSG')) %>%
  left_join(gtf,by='gene_id')
ggplot(df,aes(log2FoldChange, -log10(pvalue), color=sig)) + geom_point(size=.5) + 
  ggtitle('Der_Ctl12 vs Der_3BDO12 differential expressed gene') +
  geom_hline(yintercept = -log10(0.01), color = 'red', linetype = "dashed") + 
  geom_vline(xintercept = 2, color = "green", linetype = "dashed") + 
  geom_vline(xintercept = -2, linetype = "dashed", color = "green") +
  scale_color_manual(values = c('red','black'))

contrast_3BDO_der_24 <- c("group", "Der_3BDO24", "Der_Ctrl24")
res_3BDO_der_24_unshrunken <- results(dds, contrast=contrast_3BDO_der_24)
res_3BDO_der_24 <- lfcShrink(dds, contrast=contrast_3BDO_der_24, res=res_3BDO_der_24_unshrunken)
plotMA(res_3BDO_der_24_unshrunken)
plotMA(res_3BDO_der_24)
df = res_3BDO_der_24_unshrunken%>% data.frame()
ggplot(df,aes(log2FoldChange, -log10(padj))) + geom_point(size=.5) + 
  ggtitle('Der_3BDO24 vs Der_Ctl24 differential expressed gene') +
  geom_hline(yintercept = -log10(0.05), color = 'red', linetype = "dashed") + 
  geom_vline(xintercept = 1.5, color = "green", linetype = "dashed") + 
  geom_vline(xintercept = -1.5, linetype = "dashed", color = "green")

contrast_3BDO_epi_12 <- c("group", "Epi_3BDO12", "Epi_Ctrl12")
res_3BDO_epi_12_unshrunken <- results(dds, contrast=contrast_3BDO_epi_12)
plotMA(res_3BDO_epi_12_unshrunken)
df = res_3BDO_epi_12_unshrunken%>% data.frame()
ggplot(df,aes(log2FoldChange, -log10(padj))) + geom_point(size=.5) + 
  ggtitle('Epi_3BDO12 VS Epi_Ctrl differential expressed gene') +
  geom_hline(yintercept = -log10(0.05), color = 'red', linetype = "dashed") + 
  geom_vline(xintercept = 1.5, color = "green", linetype = "dashed") + 
  geom_vline(xintercept = -1.5, linetype = "dashed", color = "green")

contrast_3BDO_epi_24 <- c("group", "Epi_3BDO24", "Epi_Ctrl24")
res_3BDO_epi_24_unshrunken <- results(dds, contrast=contrast_3BDO_epi_24)
plotMA(res_3BDO_epi_24_unshrunken)
df = res_3BDO_epi_24_unshrunken%>% data.frame()
ggplot(df,aes(log2FoldChange, -log10(padj))) + geom_point(size=.5) + 
  ggtitle('Epi_3BDO24 VS Epi_Ctrl24 differential expressed gene') +
  geom_hline(yintercept = -log10(0.05), color = 'red', linetype = "dashed") + 
  geom_vline(xintercept = 1.5, color = "green", linetype = "dashed") + 
  geom_vline(xintercept = -1.5, linetype = "dashed", color = "green")




