#!/bin/bash
#BSUB -J xunwei
#BSUB -o output/%J.out
#BSUB -e output/%J.err

#Step 1 : STAR alignment

echo '---Running STAR NOW---'
module load star/2.5.3
echo '----Module loaded running now----'

OUT='./output_star/'
OUTBAM='./output_bam/'
TMP='tmp'
STAR_OUT='./star_output/'

mkdir ${OUT}
mkdir ${OUTBAM}
mkdir ${STAR_OUT}

SMP=$1

# Run the actual star aligner

STAR --outTmpDir tmp --genomeDir /PHShome/yz843/czlabwork/Hu_STAR_REF \
--outSAMtype BAM SortedByCoordinate --outFileNamePrefix ${STAR_OUT} \
--readFilesIn $2 --runThreadN 2 \
--sjdbGTFfile /PHShome/yz843/czlabwork/annotation/human/Homo_sapiens.GRCh38.99.gtf \
--twopassMode Basic --quantMode TranscriptomeSAM GeneCounts \
--readFilesCommand zcat 
cp ${STAR_OUT}Aligned.sortedByCoord.out.bam ${OUTBAM}${SMP}.sortedByCoord.bam
cp ${STAR_OUT}Aligned.toTranscriptome.out.bam ${OUTBAM}${SMP}.toTranscriptome.bam
cp ${STAR_OUT}SJ.out.tab ${OUT}${SMP}.SJ.out.tab 
cp ${STAR_OUT}Log.final.out ${OUT}${SMP}.Log.final.out 
cp ${STAR_OUT}Log.out ${OUT}${SMP}.Log.out 
cp ${STAR_OUT}Log.progress.out ${OUT}${SMP}.Log.progress.out 
cp ${STAR_OUT}ReadsPerGene.out.tab ${OUT}${SMP}.ReadsPerGene.out.tab 
rm -r ${STAR_OUT} 
rm -r tmp







